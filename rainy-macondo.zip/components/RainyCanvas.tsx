
import React, { useEffect, useRef } from 'react';
import p5 from 'p5';
import { VERT_SHADER, FRAG_SHADER } from '../shaders';

export const RainyCanvas: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const p5InstanceRef = useRef<p5 | null>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    // Define the Sketch
    const sketch = (p: p5) => {
      let rainShader: p5.Shader;
      let textLayer: p5.Graphics;

      const macondoText = [
        "Macondo was raining.",
        "It had been raining for four years, eleven months, and two days.",
        "There were periods of drizzle when everyone put on their full dress and a convalescent look to celebrate the clearing, but the people soon grew accustomed to interpreting the pauses as signs of redoubled rain.",
        "The sky crumbled into a set of storms.",
        "Air became heavy and humid, sticking to the skin like a warm cloth.",
        "Time passed, dripping slowly.",
        "Silence was broken only by the sound of water hitting the roofs."
      ];
      
      p.setup = () => {
        // Use WEBGL mode for shaders
        const canvas = p.createCanvas(containerRef.current!.clientWidth, containerRef.current!.clientHeight, p.WEBGL);
        canvas.parent(containerRef.current!);
        
        // Performance settings
        p.pixelDensity(1); 
        p.noStroke();

        // Create the shader
        rainShader = p.createShader(VERT_SHADER, FRAG_SHADER);

        // Initialize the background text texture
        createTextLayer();
      };

      const createTextLayer = () => {
        if (p.width === 0 || p.height === 0) return;

        // Create an off-screen graphics buffer
        textLayer = p.createGraphics(p.width, p.height);
        
        // Background color (Light Grey)
        textLayer.background(210, 212, 215); 
        
        // Text Settings
        textLayer.fill(30, 35, 40); // Dark Grey Text
        textLayer.noStroke();
        textLayer.textFont('Georgia'); // Serif font for book feel
        
        // Responsive font size
        const fontSize = Math.max(20, p.width / 45);
        textLayer.textSize(fontSize);
        textLayer.textLeading(fontSize * 1.5);
        textLayer.textAlign(p.LEFT, p.TOP);
        
        const margin = 40;
        let x = margin;
        let y = margin;
        const w = p.width - margin * 2;
        
        // Fill screen with text paragraphs
        while (y < p.height) {
          const sentence = p.random(macondoText);
          
          // Draw text and get estimated height (simplified calculation)
          textLayer.text(sentence, x, y, w);
          
          // Move cursor down roughly based on length of text
          // Note: p5.Graphics doesn't easily return rendered height of text box, 
          // so we approximate or just stack them closely.
          const estimatedLines = Math.ceil(textLayer.textWidth(sentence) / w) + 1;
          y += estimatedLines * (fontSize * 1.6) + 10;
        }
      };

      p.draw = () => {
        // Activate the shader
        p.shader(rainShader);

        // Pass uniforms to shader
        rainShader.setUniform('u_resolution', [p.width, p.height]);
        rainShader.setUniform('u_time', p.millis() / 1000.0);
        
        if (textLayer) {
            rainShader.setUniform('u_texture', textLayer);
        }

        // Draw a plane covering the canvas
        // In WEBGL mode, the camera is at (0,0,z) looking at (0,0,0).
        // plane(w, h) draws a rectangle centered at 0,0.
        p.rectMode(p.CENTER);
        p.plane(p.width, p.height);
      };

      p.windowResized = () => {
        if (containerRef.current) {
          p.resizeCanvas(containerRef.current.clientWidth, containerRef.current.clientHeight);
          createTextLayer(); // Re-generate text on resize
        }
      };
    };

    // Instantiate p5
    p5InstanceRef.current = new p5(sketch);

    // Cleanup on unmount
    return () => {
      if (p5InstanceRef.current) {
        p5InstanceRef.current.remove();
        p5InstanceRef.current = null;
      }
    };
  }, []);

  return (
    <div 
      ref={containerRef} 
      className="w-full h-full bg-neutral-900"
    />
  );
};
