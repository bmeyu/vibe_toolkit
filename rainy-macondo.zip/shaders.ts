
/**
 * Standard p5.js vertex shader
 * Uses standard matrices to map p5 geometry to clip space correctly.
 */
export const VERT_SHADER = `
attribute vec3 aPosition;
attribute vec2 aTexCoord;

uniform mat4 uProjectionMatrix;
uniform mat4 uModelViewMatrix;

varying vec2 vTexCoord;

void main() {
  vTexCoord = aTexCoord;
  gl_Position = uProjectionMatrix * uModelViewMatrix * vec4(aPosition, 1.0);
}
`;

/**
 * Rain simulation fragment shader.
 * Generates procedural rain drops and distorts the background texture.
 * Includes "Heart of the Rain" style drop physics + global falling motion.
 */
export const FRAG_SHADER = `
precision highp float;

varying vec2 vTexCoord;

uniform sampler2D u_texture;
uniform float u_time;
uniform vec2 u_resolution;

// Random function
float N21(vec2 p) {
    p = fract(p * vec2(123.34, 345.45));
    p += dot(p, p + 34.345);
    return fract(p.x * p.y);
}

// Single rain drop layer
vec3 layer(vec2 uv, float t) {
    // Aspect ratio correction
    vec2 aspect = vec2(2.0, 1.0);
    vec2 uv2 = uv * aspect * 15.0; 
    
    vec2 id = floor(uv2);
    vec2 n = fract(uv2) - 0.5; 
    
    // Calculate random speed and offset for each column
    float t_col = t + N21(id.xx) * 6.28; 
    
    // Main drop vertical movement within the grid cell
    // The complex sin function simulates the physics of a drop hanging, then falling quickly
    float y = -sin(t_col + sin(t_col + sin(t_col) * 0.5)) * 0.45; 
    
    // Position of the main drop
    vec2 p1 = vec2(0.0, y); 
    
    vec2 o1 = (n - p1) / aspect; 
    float d = length(o1); 
    
    // Shape the main drop
    float m1 = smoothstep(0.07, 0.0, d);
    
    // Trail drops (residue left behind)
    vec2 o2 = (fract(uv2 * vec2(1.0, 2.0)) - 0.5) / vec2(1.0, 2.0);
    float d2 = length(o2);
    
    // Mask to only show trail above the main drop
    float m2 = smoothstep(0.3 * (0.5 - y), 0.0, d2); 
    
    // Fade trail based on position (higher = barely visible)
    if(n.x > 0.4 || n.x < -0.4) m2 = 0.0; // Clip trail width
    if(n.y < y) m2 = 0.0; // Only trail above drop
    
    // Combine drop + trail
    // xy: normal distortion vector, z: mask/alpha
    return vec3(o1 * m1 * 40.0 + o2 * m2 * 20.0, m1 + m2);
}

void main() {
    vec2 uv = vTexCoord;
    // Fix P5 texture flipping
    uv.y = 1.0 - uv.y;
    
    float t = u_time * 0.2;
    
    // Create multiple layers of rain for depth
    // We add a vertical shift (t * 0.2) to uv.y before passing to layer
    // so the whole grid moves downwards slowly, simulating falling rain
    
    // Layer 1
    vec3 drops1 = layer(uv + vec2(0.0, t * 1.0), u_time * 1.5);
    
    // Layer 2 (Smaller, faster, different offset)
    vec3 drops2 = layer((uv * 1.5) + vec2(4.23, t * 1.5), u_time * 2.0 + 42.0);
    
    float drops = drops1.z + drops2.z;
    vec2 distortion = drops1.xy + drops2.xy; 
    
    // Refraction
    vec2 finalUV = uv + distortion * 0.02; 
    
    // Fog/Condensation noise
    float fog = N21(uv * 100.0 + t) * 0.005;
    finalUV += fog;

    // Sample the background text texture with distorted UVs
    vec3 col = texture2D(u_texture, finalUV).rgb;
    
    // Blur simulation (cheap version): Mix in a slightly offset sample
    // or just rely on the distortion to break up the text edges
    
    // Lighting & Shading
    
    // Darken edges of drops (Fresnel-ish effect)
    col -= smoothstep(0.0, 2.0, length(distortion)) * 0.2;
    
    // Specular Highlight
    vec2 lightPos = normalize(vec2(1.0, 2.0));
    float specular = dot(normalize(distortion), lightPos);
    // Sharp highlight for wet look
    specular = pow(max(0.0, specular), 15.0) * 0.8; 
    
    col += specular;
    
    // Color Grading: Melancholy Blue/Grey Tint
    vec3 tint = vec3(0.9, 0.95, 1.0);
    col *= tint;
    
    // Vignette
    float vignette = smoothstep(1.2, 0.4, length(vTexCoord - 0.5));
    col *= vignette;

    gl_FragColor = vec4(col, 1.0);
}
`;
